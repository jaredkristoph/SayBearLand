'use strict';
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const { createStore } = require('./lib/store');
const http = require('http');
const A = require('./lib/auth');
const L = require('./public/layout.js');
const { createWorld } = require('./lib/world');

function createApp(store = createStore(), env = process.env) {
  const SECRET = env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
  if (!env.SESSION_SECRET) console.warn('SESSION_SECRET not set: logins reset on every restart.');
  const ADMINS = (env.ADMIN_USERNAMES || 'admin').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  const SECURE = env.NODE_ENV === 'production';
  const SESSION_MS = 7 * 24 * 3600 * 1000;

  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use('/api/admin/logo', express.json({ limit: '700kb' }));
  app.use(express.json({ limit: '20kb' }));
  app.use((req, res, next) => {
    res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'DENY' });
    next();
  });
  // State-changing calls must be JSON. A cross-site form post cannot send that.
  app.use('/api', (req, res, next) => {
    if (req.method !== 'GET' && !req.is('application/json')) return res.status(415).json({ error: 'JSON only' });
    next();
  });

  const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
  const userKey = (u) => `user:${u}`;
  const publicUser = (u) => ({
    username: u.username, name: u.name, role: u.role, admin: !!u.admin,
    mustChangePassword: !!u.mustChange, costume: u.costume, color: u.color, coins: u.coins || 0,
  });

  async function limit(key, max, windowSec) {
    const n = await store.incr(key);
    if (n === 1) await store.expire(key, windowSec);
    return n <= max;
  }

  function readCookie(req, name) {
    const m = (req.headers.cookie || '').split(/;\s*/).find((c) => c.startsWith(name + '='));
    return m ? decodeURIComponent(m.slice(name.length + 1)) : null;
  }
  function setSession(res, username) {
    const token = A.sign({ u: username, exp: Date.now() + SESSION_MS }, SECRET);
    res.cookie('cl_session', token, { httpOnly: true, sameSite: 'lax', secure: SECURE, maxAge: SESSION_MS, path: '/' });
  }

  async function requireUser(req, res, next) {
    const p = A.verify(readCookie(req, 'cl_session'), SECRET);
    const user = p && (await store.get(userKey(p.u)));
    if (!user) return res.status(401).json({ error: 'Not signed in' });
    req.user = user;
    next();
  }
  const requireAdmin = (req, res, next) => (req.user.admin ? next() : res.status(403).json({ error: 'Admins only' }));


  app.post('/api/signup', wrap(async (req, res) => {
    if (!(await limit(`rl:signup:${req.ip}`, 10, 3600))) return res.status(429).json({ error: 'Too many sign-ups. Try again later.' });
    const username = String(req.body.username || '').trim().toLowerCase();
    const name = String(req.body.name || '').trim().slice(0, 24);
    const role = req.body.role;
    if (!A.USERNAME_RE.test(username)) return res.status(400).json({ error: 'Username must be 3 to 20 letters, numbers or underscores.' });
    if (name.length < 1) return res.status(400).json({ error: 'Enter a display name.' });
    if (!A.ROLES.includes(role)) return res.status(400).json({ error: 'Choose a role.' });
    const password = A.generatePassword();
    const user = {
      username, name, role, admin: ADMINS.includes(username), mustChange: true,
      costume: 'bear', color: 0x7aa2ff, coins: 0, passwordHash: A.hashPassword(password), createdAt: Date.now(),
    };
    const ok = await store.set(userKey(username), user, { nx: true });
    if (!ok) return res.status(409).json({ error: 'That username is taken.' });
    await store.sadd('users', username);
    res.status(201).json({ username, temporaryPassword: password, note: 'Shown once. You must change it at first login.' });
  }));

  app.post('/api/login', wrap(async (req, res) => {
    const username = String(req.body.username || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!(await limit(`rl:login:${req.ip}:${username}`, 8, 600))) return res.status(429).json({ error: 'Too many attempts. Wait a few minutes.' });
    const user = await store.get(userKey(username));
    // Hash even for unknown users so response time does not reveal which usernames exist.
    const good = A.verifyPassword(password, user ? user.passwordHash : A.hashPassword('x'));
    if (!user || !good) return res.status(401).json({ error: 'Wrong username or password.' });
    setSession(res, username);
    res.json({ user: publicUser(user) });
  }));

  app.post('/api/logout', (req, res) => { res.clearCookie('cl_session', { path: '/' }); res.json({ ok: true }); });

  app.get('/api/me', wrap(requireUser), (req, res) => res.json({ user: publicUser(req.user) }));

  app.post('/api/change-password', wrap(requireUser), wrap(async (req, res) => {
    const { oldPassword, newPassword } = req.body || {};
    if (!A.verifyPassword(String(oldPassword || ''), req.user.passwordHash)) return res.status(401).json({ error: 'Current password is wrong.' });
    if (typeof newPassword !== 'string' || newPassword.length < 8 || newPassword.length > 100) return res.status(400).json({ error: 'New password must be 8 to 100 characters.' });
    if (newPassword === oldPassword) return res.status(400).json({ error: 'Choose a different password.' });
    req.user.passwordHash = A.hashPassword(newPassword);
    req.user.mustChange = false;
    await store.set(userKey(req.user.username), req.user);
    res.json({ user: publicUser(req.user) });
  }));

  app.post('/api/avatar', wrap(requireUser), wrap(async (req, res) => {
    const { costume, color } = req.body || {};
    if (!A.COSTUMES.includes(costume) || !Number.isInteger(color) || color < 0 || color > 0xffffff) return res.status(400).json({ error: 'Invalid outfit.' });
    req.user.costume = costume; req.user.color = color;
    await store.set(userKey(req.user.username), req.user);
    res.json({ user: publicUser(req.user) });
  }));

  app.get('/api/admin/users', wrap(requireUser), requireAdmin, wrap(async (req, res) => {
    const names = await store.smembers('users');
    const users = (await Promise.all(names.map((n) => store.get(userKey(n))))).filter(Boolean).map(publicUser);
    res.json({ users });
  }));

  app.post('/api/admin/reset-password', wrap(requireUser), requireAdmin, wrap(async (req, res) => {
    const target = await store.get(userKey(String(req.body.username || '').toLowerCase()));
    if (!target) return res.status(404).json({ error: 'No such user.' });
    const password = A.generatePassword();
    target.passwordHash = A.hashPassword(password); target.mustChange = true;
    await store.set(userKey(target.username), target);
    res.json({ username: target.username, temporaryPassword: password });
  }));


  // ---- shared content: layout, announcements, logo, bots ----
  const BOT_ROLES = ['CEO', 'Tester', 'CCO', 'Web Developer', 'Application Developer', 'Designer', 'HR', 'Support'];
  const BOT_COSTUMES = ['bear', 'cat', 'duck', 'robot', 'crown', 'none'];
  const DEFAULT_BOTS = [
    { id: 'ceo', name: 'Boss Bot', role: 'CEO', costume: 'crown', color: 0xffd166, speed: 1.4 },
    { id: 'tess', name: 'Tess-Bot', role: 'Tester', costume: 'robot', color: 0xc9b6ff, speed: 1.6 },
  ];
  const DEFAULT_NEWS = [
    { id: 'n1', title: 'Sprint demo', body: 'Friday 3 PM in the glass meeting room.', color: 'gold' },
    { id: 'n2', title: 'New hire', body: 'Welcome Kai, joining as Web Developer on Monday.', color: 'mint' },
  ];
  const getLayout = async () => (await store.get('layout')) || L.defaultLayout();
  const getBots = async () => (await store.get('bots')) || DEFAULT_BOTS;
  const authenticate = async (req) => {
    const p = A.verify(readCookie(req, 'cl_session'), SECRET);
    return p ? store.get(userKey(p.u)) : null;
  };
  const world = createWorld({ authenticate, getLayout, getBots, store });
  app.locals.world = world;

  app.get('/api/layout', wrap(requireUser), wrap(async (req, res) => res.json({ layout: await getLayout() })));
  app.put('/api/admin/layout', wrap(requireUser), requireAdmin, wrap(async (req, res) => {
    const v = L.validate(req.body && req.body.layout);
    if (v.error) return res.status(400).json({ error: v.error });
    await store.set('layout', v.layout);
    await world.reload(); world.refreshClients();
    res.json({ layout: v.layout });
  }));
  app.post('/api/admin/layout/reset', wrap(requireUser), requireAdmin, wrap(async (req, res) => {
    await store.del('layout'); await world.reload(); world.refreshClients();
    res.json({ layout: L.defaultLayout() });
  }));

  app.get('/api/announcements', wrap(requireUser), wrap(async (req, res) => res.json({ items: (await store.get('news')) || DEFAULT_NEWS })));
  app.put('/api/admin/announcements', wrap(requireUser), requireAdmin, wrap(async (req, res) => {
    const items = req.body && req.body.items;
    if (!Array.isArray(items) || items.length > 20) return res.status(400).json({ error: 'Send up to 20 announcements.' });
    const clean = items.map((n, i) => ({
      id: String(n.id || 'n' + i).slice(0, 16), title: String(n.title || '').trim().slice(0, 60), body: String(n.body || '').trim().slice(0, 300),
      color: ['gold', 'mint', 'pink'].includes(n.color) ? n.color : 'gold',
    })).filter((n) => n.title);
    await store.set('news', clean); world.refreshClients();
    res.json({ items: clean });
  }));

  app.get('/api/logo', wrap(requireUser), wrap(async (req, res) => res.json({ dataUrl: (await store.get('logo')) || null })));
  app.put('/api/admin/logo', wrap(requireUser), requireAdmin, wrap(async (req, res) => {
    const d = req.body && req.body.dataUrl;
    if (d === null) await store.del('logo');
    else if (typeof d === 'string' && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(d) && d.length < 500000) await store.set('logo', d);
    else return res.status(400).json({ error: 'Upload a PNG, JPEG or WebP under 350 KB.' });
    world.refreshClients();
    res.json({ ok: true });
  }));

  app.get('/api/bots', wrap(requireUser), wrap(async (req, res) => res.json({ bots: await getBots(), roles: BOT_ROLES, costumes: BOT_COSTUMES })));
  app.put('/api/admin/bots', wrap(requireUser), requireAdmin, wrap(async (req, res) => {
    const bots = req.body && req.body.bots;
    if (!Array.isArray(bots) || bots.length > 12) return res.status(400).json({ error: 'Up to 12 bots.' });
    const clean = [];
    for (let i = 0; i < bots.length; i++) {
      const b = bots[i] || {};
      const name = String(b.name || '').trim().slice(0, 16);
      if (!name) return res.status(400).json({ error: 'Every bot needs a name.' });
      if (!BOT_ROLES.includes(b.role) || !BOT_COSTUMES.includes(b.costume) || !Number.isInteger(b.color) || b.color < 0 || b.color > 0xffffff) return res.status(400).json({ error: 'Invalid bot settings.' });
      clean.push({ id: String(b.id || 'b' + i + Date.now().toString(36)).replace(/[^a-z0-9_]/gi, '').slice(0, 16) || 'b' + i, name, role: b.role, costume: b.costume, color: b.color, speed: Math.min(3, Math.max(0.5, Number(b.speed) || 1.5)) });
    }
    await store.set('bots', clean); await world.reload(); world.refreshClients();
    res.json({ bots: clean });
  }));

  app.get('/healthz', (req, res) => res.json({ ok: true, store: store.kind, online: world.online() }));

  app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
  app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    console.error(err);
    res.status(err.status || 500).json({ error: 'Something went wrong.' });
  });
  return app;
}

if (require.main === module) {
  const store = createStore();
  const port = process.env.PORT || 3000;
  const app = createApp(store);
  const server = http.createServer(app);
  app.locals.world.handleUpgrade(server);
  server.listen(port, () => console.log(`Cyberland on :${port} (storage: ${store.kind})`));
}
module.exports = { createApp };
